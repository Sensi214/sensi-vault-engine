# SENSI Vault Engine

GitHub/backend files only.

## Setup

```bash
npm install
npm start
```

Create a real `.env` file from `.env.example`.
